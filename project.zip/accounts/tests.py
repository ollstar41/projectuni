from django.contrib.auth.models import Group, User
from django.core.cache import cache
from django.test import TestCase, override_settings

from .models import Ticket
from .roles import MODERATOR_GROUP
from .security import sanitize_log_value


class SecurityRegressionTests(TestCase):
    def setUp(self):
        cache.clear()

    def test_x_forwarded_for_does_not_bypass_rate_limit_by_default(self):
        for attempt in range(5):
            response = self.client.post(
                "/",
                {
                    "username": "admin",
                    "email": "admin@example.com",
                    "password": "WrongPassword123!",
                },
                HTTP_X_FORWARDED_FOR=f"1.1.1.{attempt}",
            )
            self.assertEqual(response.status_code, 200)

        response = self.client.post(
            "/",
            {
                "username": "admin",
                "email": "admin@example.com",
                "password": "WrongPassword123!",
            },
            HTTP_X_FORWARDED_FOR="9.9.9.9",
        )

        self.assertEqual(response.status_code, 429)

    @override_settings(TRUSTED_PROXY_IPS={"127.0.0.1"})
    def test_x_forwarded_for_is_used_only_for_trusted_proxy(self):
        for attempt in range(5):
            response = self.client.post(
                "/",
                {
                    "username": "admin",
                    "email": "admin@example.com",
                    "password": "WrongPassword123!",
                },
                HTTP_X_FORWARDED_FOR="2.2.2.2",
            )
            self.assertEqual(response.status_code, 200)

        response = self.client.post(
            "/",
            {
                "username": "different_user",
                "email": "different@example.com",
                "password": "WrongPassword123!",
            },
            HTTP_X_FORWARDED_FOR="3.3.3.3",
        )

        self.assertEqual(response.status_code, 200)

    def test_log_values_escape_new_lines(self):
        payload = "admin\nINFO security successful_login ip=8.8.8.8 user_id=1 username=admin"
        sanitized = sanitize_log_value(payload)

        self.assertNotIn("\n", sanitized)
        self.assertIn("\\x0a", sanitized)

    def test_ticket_text_is_escaped_when_rendered(self):
        user = User.objects.create_user(
            username="student",
            email="student@example.com",
            password="StrongPassword123!",
        )
        Ticket.objects.create(
            user=user,
            title="<script>alert(1)</script>",
            description="<img src=x onerror=alert(1)> ticket description",
            priority=Ticket.PRIORITY_HIGH,
        )

        self.client.force_login(user)
        response = self.client.get("/dashboard/")

        self.assertContains(response, "&lt;script&gt;alert(1)&lt;/script&gt;", html=False)
        self.assertNotContains(response, "<script>alert(1)</script>", html=False)
        self.assertNotContains(response, "<img src=x onerror=alert(1)>", html=False)

    def test_sql_injection_style_ticket_payload_is_saved_as_text(self):
        user = User.objects.create_user(
            username="student",
            email="student@example.com",
            password="StrongPassword123!",
        )
        self.client.force_login(user)
        payload = "printer error ' OR '1'='1"

        response = self.client.post(
            "/tickets/new/",
            {
                "title": payload,
                "description": "The ticket contains SQL-like text but it must stay plain text.",
                "priority": Ticket.PRIORITY_MEDIUM,
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(Ticket.objects.filter(user=user, title=payload).exists())

    def test_dashboard_shows_only_current_users_tickets(self):
        user_a = User.objects.create_user("user_a", "a@example.com", "StrongPassword123!")
        user_b = User.objects.create_user("user_b", "b@example.com", "StrongPassword123!")
        Ticket.objects.create(user=user_a, title="User A ticket", description="Visible only to user A")
        Ticket.objects.create(user=user_b, title="User B ticket", description="Visible only to user B")

        self.client.force_login(user_a)
        response = self.client.get("/dashboard/")

        self.assertContains(response, "User A ticket")
        self.assertNotContains(response, "User B ticket")

    def test_moderator_can_see_all_tickets(self):
        moderator = User.objects.create_user("moderator", "mod@example.com", "StrongPassword123!")
        group = Group.objects.create(name=MODERATOR_GROUP)
        moderator.groups.add(group)
        user_a = User.objects.create_user("user_a", "a@example.com", "StrongPassword123!")
        user_b = User.objects.create_user("user_b", "b@example.com", "StrongPassword123!")
        Ticket.objects.create(user=user_a, title="User A ticket", description="Visible to support")
        Ticket.objects.create(user=user_b, title="User B ticket", description="Visible to support")

        self.client.force_login(moderator)
        response = self.client.get("/dashboard/")

        self.assertContains(response, "User A ticket")
        self.assertContains(response, "User B ticket")

    def test_user_cannot_open_other_users_ticket(self):
        user_a = User.objects.create_user("user_a", "a@example.com", "StrongPassword123!")
        user_b = User.objects.create_user("user_b", "b@example.com", "StrongPassword123!")
        ticket = Ticket.objects.create(user=user_b, title="Private ticket", description="Secret issue")

        self.client.force_login(user_a)
        response = self.client.get(f"/tickets/{ticket.id}/")

        self.assertEqual(response.status_code, 403)

    def test_ticket_requires_support_resolution_before_user_can_close(self):
        moderator = User.objects.create_user("moderator", "mod@example.com", "StrongPassword123!")
        group = Group.objects.create(name=MODERATOR_GROUP)
        moderator.groups.add(group)
        user = User.objects.create_user("user", "user@example.com", "StrongPassword123!")
        ticket = Ticket.objects.create(user=user, title="Broken laptop", description="The laptop does not turn on")

        self.client.force_login(user)
        response = self.client.post(f"/tickets/{ticket.id}/confirm-close/")
        self.assertEqual(response.status_code, 403)

        self.client.force_login(moderator)
        response = self.client.post(f"/tickets/{ticket.id}/status/", {"status": Ticket.STATUS_RESOLVED})
        self.assertEqual(response.status_code, 302)

        self.client.force_login(user)
        response = self.client.post(f"/tickets/{ticket.id}/confirm-close/")
        self.assertEqual(response.status_code, 302)
        ticket.refresh_from_db()
        self.assertEqual(ticket.status, Ticket.STATUS_CLOSED)
