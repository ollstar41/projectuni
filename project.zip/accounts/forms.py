from django import forms
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

from .models import Ticket


login_validator = RegexValidator(
    regex=r"^[A-Za-z0-9_@.+-]+$",
    message="Login can contain only letters, numbers, and @/./+/-/_ characters.",
)


class LoginForm(forms.Form):
    username = forms.CharField(
        label="Login",
        max_length=150,
        validators=[login_validator],
        widget=forms.TextInput(attrs={"placeholder": "Enter your login", "autocomplete": "username"}),
    )
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={"placeholder": "Enter your email", "autocomplete": "email"}),
    )
    password = forms.CharField(
        label="Password",
        min_length=12,
        widget=forms.PasswordInput(attrs={"placeholder": "Enter your password", "autocomplete": "current-password"}),
    )


class MfaForm(forms.Form):
    code = forms.CharField(
        label="MFA code",
        min_length=6,
        max_length=6,
        widget=forms.TextInput(attrs={"placeholder": "Enter 6-digit code", "autocomplete": "one-time-code"}),
    )


class RegistrationForm(forms.ModelForm):
    password = forms.CharField(
        label="Password",
        min_length=12,
        widget=forms.PasswordInput(attrs={"placeholder": "Create a password", "autocomplete": "new-password"}),
    )
    password_confirm = forms.CharField(
        label="Confirm password",
        widget=forms.PasswordInput(attrs={"placeholder": "Repeat your password", "autocomplete": "new-password"}),
    )

    class Meta:
        model = User
        fields = ["username", "email"]
        labels = {"username": "Login", "email": "Email"}
        widgets = {
            "username": forms.TextInput(attrs={"placeholder": "Choose a login", "autocomplete": "username"}),
            "email": forms.EmailInput(attrs={"placeholder": "Enter your email", "autocomplete": "email"}),
        }

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        login_validator(username)
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This login is already taken.")
        return username

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")
        if password and password_confirm and password != password_confirm:
            self.add_error("password_confirm", "Passwords do not match.")
        if password:
            try:
                validate_password(password)
            except forms.ValidationError as error:
                self.add_error("password", error)
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["title", "description", "priority"]
        widgets = {
            "title": forms.TextInput(attrs={"placeholder": "Short summary of the problem"}),
            "description": forms.Textarea(attrs={"placeholder": "Describe the issue", "rows": 6}),
            "priority": forms.Select(),
        }

    def clean_title(self):
        title = self.cleaned_data["title"].strip()
        if len(title) < 5:
            raise forms.ValidationError("Title must be at least 5 characters long.")
        return title

    def clean_description(self):
        description = self.cleaned_data["description"].strip()
        if len(description) < 10:
            raise forms.ValidationError("Description must be at least 10 characters long.")
        return description


class TicketStatusForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["status"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["status"].choices = [
            (Ticket.STATUS_IN_PROGRESS, "In progress"),
            (Ticket.STATUS_RESOLVED, "Resolved by support"),
        ]
