from django.contrib import admin

from .models import Ticket


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "priority", "status", "created_at")
    list_filter = ("priority", "status", "created_at")
    search_fields = ("title", "description", "user__username", "user__email")
