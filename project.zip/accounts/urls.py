from django.urls import path

from . import views


urlpatterns = [
    path("", views.login_view, name="login"),
    path("mfa/", views.mfa_view, name="mfa"),
    path("register/", views.register_view, name="register"),
    path("dashboard/", views.dashboard_view, name="dashboard"),
    path("tickets/new/", views.create_ticket_view, name="create_ticket"),
    path("tickets/<int:ticket_id>/", views.ticket_detail_view, name="ticket_detail"),
    path("tickets/<int:ticket_id>/status/", views.update_ticket_status_view, name="update_ticket_status"),
    path("tickets/<int:ticket_id>/confirm-close/", views.confirm_ticket_closed_view, name="confirm_ticket_closed"),
    path("logout/", views.logout_view, name="logout"),
]
