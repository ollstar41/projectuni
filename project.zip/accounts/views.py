from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import LoginForm, MfaForm, RegistrationForm, TicketForm, TicketStatusForm
from .models import Ticket
from .roles import is_admin, is_moderator, is_privileged, role_label
from .security import (
    clear_failed_logins,
    log_mfa_failed,
    log_ticket_created,
    log_ticket_status_changed,
    log_ticket_viewed,
    is_login_rate_limited,
    log_logout,
    log_successful_login,
    record_failed_login,
)


def _mfa_code_for_user(user):
    if is_admin(user):
        return getattr(settings, "ADMIN_MFA_CODE", "111111")
    if is_moderator(user):
        return getattr(settings, "MODERATOR_MFA_CODE", "222222")
    return ""


def _tickets_for_user(user):
    if is_privileged(user):
        return Ticket.objects.select_related("user", "resolved_by")
    return Ticket.objects.filter(user=user).select_related("user", "resolved_by")


def _get_visible_ticket(user, ticket_id):
    ticket = get_object_or_404(Ticket.objects.select_related("user", "resolved_by"), id=ticket_id)
    if is_privileged(user) or ticket.user_id == user.id:
        return ticket
    raise PermissionDenied


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    posted_username = request.POST.get("username", "") if request.method == "POST" else ""
    posted_email = request.POST.get("email", "") if request.method == "POST" else ""

    if request.method == "POST" and is_login_rate_limited(request, posted_username, posted_email):
        messages.error(request, "Too many failed login attempts. Please try again in 15 minutes.")
        response = render(request, "accounts/login.html", {"form": LoginForm()})
        response.status_code = 429
        return response

    form = LoginForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        username = form.cleaned_data["username"]
        email = form.cleaned_data["email"]
        password = form.cleaned_data["password"]

        matching_user = User.objects.filter(username__iexact=username, email__iexact=email).first()
        user = None
        if matching_user:
            user = authenticate(request, username=matching_user.username, password=password)

        if matching_user and user is not None:
            if is_privileged(user):
                request.session["pending_mfa_user_id"] = user.id
                request.session["pending_mfa_username"] = username
                request.session["pending_mfa_email"] = email
                messages.info(request, "Enter the MFA code for this privileged account.")
                return redirect("mfa")
            clear_failed_logins(request, username, email)
            login(request, user)
            log_successful_login(request, user)
            messages.success(request, "You have signed in successfully.")
            return redirect("dashboard")

        record_failed_login(request, username, email)
        messages.error(
            request,
            "Account not found or credentials are incorrect. Please check your details or create an account.",
        )
    elif request.method == "POST":
        record_failed_login(
            request,
            request.POST.get("username", "invalid-form"),
            request.POST.get("email", "invalid-form"),
        )

    return render(request, "accounts/login.html", {"form": form})


def mfa_view(request):
    user_id = request.session.get("pending_mfa_user_id")
    if not user_id:
        return redirect("login")

    pending_user = get_object_or_404(User, id=user_id)
    form = MfaForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        if form.cleaned_data["code"] == _mfa_code_for_user(pending_user):
            clear_failed_logins(
                request,
                request.session.get("pending_mfa_username", ""),
                request.session.get("pending_mfa_email", ""),
            )
            login(request, pending_user)
            log_successful_login(request, pending_user)
            request.session.pop("pending_mfa_user_id", None)
            request.session.pop("pending_mfa_username", None)
            request.session.pop("pending_mfa_email", None)
            messages.success(request, "MFA verified. You have signed in successfully.")
            return redirect("dashboard")

        log_mfa_failed(request, pending_user)
        messages.error(request, "Invalid MFA code.")

    return render(request, "accounts/mfa.html", {"form": form})


def register_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    form = RegistrationForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Account created successfully. You can sign in now.")
        return redirect("login")

    return render(request, "accounts/register.html", {"form": form})


@login_required
def dashboard_view(request):
    tickets = list(_tickets_for_user(request.user))
    for ticket in tickets:
        log_ticket_viewed(request, ticket)
    return render(
        request,
        "accounts/dashboard.html",
        {
            "tickets": tickets,
            "role": role_label(request.user),
            "can_manage_tickets": is_privileged(request.user),
        },
    )


@login_required
def create_ticket_view(request):
    form = TicketForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        ticket = form.save(commit=False)
        ticket.user = request.user
        ticket.save()
        log_ticket_created(request, ticket)
        messages.success(request, "Ticket created successfully.")
        return redirect("dashboard")

    return render(request, "accounts/create_ticket.html", {"form": form})


@login_required
def ticket_detail_view(request, ticket_id):
    ticket = _get_visible_ticket(request.user, ticket_id)
    log_ticket_viewed(request, ticket)
    status_form = TicketStatusForm(instance=ticket) if is_privileged(request.user) else None
    return render(
        request,
        "accounts/ticket_detail.html",
        {
            "ticket": ticket,
            "status_form": status_form,
            "role": role_label(request.user),
            "can_manage_ticket": is_privileged(request.user),
            "can_confirm_close": ticket.user_id == request.user.id and ticket.status == Ticket.STATUS_RESOLVED,
        },
    )


@require_POST
@login_required
def update_ticket_status_view(request, ticket_id):
    if not is_privileged(request.user):
        raise PermissionDenied

    ticket = _get_visible_ticket(request.user, ticket_id)
    if ticket.status == Ticket.STATUS_CLOSED:
        raise PermissionDenied

    form = TicketStatusForm(request.POST, instance=ticket)
    if form.is_valid():
        old_status = ticket.status
        ticket = form.save(commit=False)
        if ticket.status == Ticket.STATUS_RESOLVED:
            ticket.resolved_by = request.user
        ticket.save()
        log_ticket_status_changed(request, ticket, old_status, ticket.status)
        messages.success(request, "Ticket status updated.")
    else:
        messages.error(request, "Invalid ticket status.")

    return redirect("ticket_detail", ticket_id=ticket_id)


@require_POST
@login_required
def confirm_ticket_closed_view(request, ticket_id):
    ticket = _get_visible_ticket(request.user, ticket_id)
    if ticket.user_id != request.user.id or ticket.status != Ticket.STATUS_RESOLVED:
        raise PermissionDenied

    old_status = ticket.status
    ticket.status = Ticket.STATUS_CLOSED
    ticket.closed_at = timezone.now()
    ticket.save(update_fields=["status", "closed_at", "updated_at"])
    log_ticket_status_changed(request, ticket, old_status, ticket.status)
    messages.success(request, "Ticket closed successfully.")
    return redirect("ticket_detail", ticket_id=ticket.id)


@require_POST
@login_required
def logout_view(request):
    log_logout(request)
    logout(request)
    messages.info(request, "You have signed out.")
    return redirect("login")
