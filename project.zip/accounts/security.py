import hashlib
import ipaddress
import logging
import re

from django.conf import settings
from django.core.cache import cache


security_logger = logging.getLogger("security")

MAX_LOGIN_ATTEMPTS = 5
LOGIN_LOCKOUT_SECONDS = 15 * 60
CONTROL_CHARACTERS = re.compile(r"[\x00-\x1f\x7f-\x9f]")


def sanitize_log_value(value, max_length=200):
    value = "" if value is None else str(value)
    value = CONTROL_CHARACTERS.sub(lambda match: f"\\x{ord(match.group()):02x}", value)
    if len(value) > max_length:
        return value[:max_length] + "...[truncated]"
    return value


def _valid_ip(value):
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return "unknown"


def get_client_ip(request):
    remote_addr = _valid_ip(request.META.get("REMOTE_ADDR", ""))
    trusted_proxies = getattr(settings, "TRUSTED_PROXY_IPS", set())

    if remote_addr in trusted_proxies:
        forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR", "")
        first_forwarded_ip = forwarded_for.split(",")[0].strip()
        return _valid_ip(first_forwarded_ip)

    return remote_addr


def _cache_key(prefix, value):
    key_hash = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return f"{prefix}:{key_hash}"


def _login_attempt_keys(request, username="", email=""):
    ip_address = get_client_ip(request)
    keys = [_cache_key("login_attempts_ip", ip_address)]
    identity = f"{username}".strip().lower() or f"{email}".strip().lower()
    if identity:
        keys.append(_cache_key("login_attempts_identity", identity))
    return keys


def is_login_rate_limited(request, username="", email=""):
    return any(cache.get(key, 0) >= MAX_LOGIN_ATTEMPTS for key in _login_attempt_keys(request, username, email))


def record_failed_login(request, username, email):
    ip_address = get_client_ip(request)
    keys = _login_attempt_keys(request, username, email)
    attempts = 0
    for key in keys:
        attempts = max(attempts, cache.get(key, 0) + 1)
        cache.set(key, cache.get(key, 0) + 1, LOGIN_LOCKOUT_SECONDS)
    security_logger.warning(
        "failed_login ip=%s username=%s email=%s attempts=%s",
        sanitize_log_value(ip_address),
        sanitize_log_value(username),
        sanitize_log_value(email),
        attempts,
    )
    return attempts


def clear_failed_logins(request, username="", email=""):
    for key in _login_attempt_keys(request, username, email):
        cache.delete(key)


def log_successful_login(request, user):
    security_logger.info(
        "successful_login ip=%s user_id=%s username=%s",
        sanitize_log_value(get_client_ip(request)),
        user.id,
        sanitize_log_value(user.username),
    )


def log_mfa_failed(request, user):
    security_logger.warning(
        "failed_mfa ip=%s user_id=%s username=%s",
        sanitize_log_value(get_client_ip(request)),
        user.id,
        sanitize_log_value(user.username),
    )


def log_logout(request):
    user = request.user
    security_logger.info(
        "logout ip=%s user_id=%s username=%s",
        sanitize_log_value(get_client_ip(request)),
        user.id if user.is_authenticated else "anonymous",
        sanitize_log_value(user.username if user.is_authenticated else "anonymous"),
    )


def log_ticket_created(request, ticket):
    security_logger.info(
        "ticket_created ip=%s user_id=%s ticket_id=%s priority=%s",
        sanitize_log_value(get_client_ip(request)),
        request.user.id,
        ticket.id,
        sanitize_log_value(ticket.priority),
    )


def log_ticket_viewed(request, ticket):
    security_logger.info(
        "ticket_viewed ip=%s user_id=%s ticket_id=%s",
        sanitize_log_value(get_client_ip(request)),
        request.user.id,
        ticket.id,
    )


def log_ticket_status_changed(request, ticket, old_status, new_status):
    security_logger.info(
        "ticket_status_changed ip=%s actor_id=%s ticket_id=%s old_status=%s new_status=%s",
        sanitize_log_value(get_client_ip(request)),
        request.user.id,
        ticket.id,
        sanitize_log_value(old_status),
        sanitize_log_value(new_status),
    )
