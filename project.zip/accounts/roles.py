MODERATOR_GROUP = "Moderator"


def is_admin(user):
    return user.is_authenticated and (user.is_superuser or user.is_staff)


def is_moderator(user):
    return user.is_authenticated and user.groups.filter(name=MODERATOR_GROUP).exists()


def is_privileged(user):
    return is_admin(user) or is_moderator(user)


def role_label(user):
    if is_admin(user):
        return "Administrator"
    if is_moderator(user):
        return "Moderator"
    return "User"
