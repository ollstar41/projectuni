from django.contrib.auth.models import Group, User
from django.core.management.base import BaseCommand

from accounts.roles import MODERATOR_GROUP


class Command(BaseCommand):
    help = "Create demo Administrator, Moderator, and User accounts."

    def handle(self, *args, **options):
        moderator_group, _ = Group.objects.get_or_create(name=MODERATOR_GROUP)

        admin = self._create_or_update_user(
            username="admin_test",
            email="admin@example.com",
            password="AdminTest123!",
            is_staff=True,
            is_superuser=True,
        )

        moderator = self._create_or_update_user(
            username="moderator_test",
            email="moderator@example.com",
            password="ModeratorTest123!",
            is_staff=False,
            is_superuser=False,
        )
        moderator.groups.add(moderator_group)

        user = self._create_or_update_user(
            username="user_test",
            email="user@example.com",
            password="UserTest123!",
            is_staff=False,
            is_superuser=False,
        )

        self.stdout.write(self.style.SUCCESS("Demo accounts are ready:"))
        self.stdout.write("Administrator: login=admin_test email=admin@example.com password=AdminTest123! MFA=111111")
        self.stdout.write(
            "Moderator: login=moderator_test email=moderator@example.com password=ModeratorTest123! MFA=222222"
        )
        self.stdout.write("User: login=user_test email=user@example.com password=UserTest123!")

    def _create_or_update_user(self, username, email, password, is_staff, is_superuser):
        user, _ = User.objects.get_or_create(username=username)
        user.email = email
        user.is_staff = is_staff
        user.is_superuser = is_superuser
        user.set_password(password)
        user.save()
        return user
